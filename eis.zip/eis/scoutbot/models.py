# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class video(models.Model):
	image_time = models.DateTimeField(auto_now = True)
	image_string = models.CharField(max_length = 2000000)
	def __str__(self):
		return self.image_string
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from .models import video
#from django.urls import reverse
from django.core.urlresolvers import reverse
import requests
import base64
from django.views import generic
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
import json
from django.http import JsonResponse, HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.shortcuts import render_to_response
from django.template import loader

def index(request):
	template = 'scoutbot/index.html'
	return render(request, template, {'username': "Mouni"})

@csrf_exempt
def saveFrame(request):
	print("entered")
	if request.POST.get('data'):
		im = video.objects.create()
		im.image_string = request.POST.get('data')
		im.image_string = 'data:image/gif;base64,' + im.image_string
		print(im.image_string)
		video.objects.all().delete()
		im.save()
		return redirect('scoutbot:displayFrame')

'''@csrf_exempt
def saveFrame(request):
	if request.method == 'POST':
		newImage = request.POST['data']
		print(newImage)
		return redirect('scoutbot:index')'''

'''@csrf_exempt
def saveFrame(request):
	print("entered outside if")
	template = 'scoutbot/image.html'
	if request.POST.get('data'):
		image = request.POST.get('data')
		image = 'data:image/gif;base64,' + image
		image1 = []
		image1.append(image)
		#im.image_string = 'data:image/gif;base64,' + im.image_string
		print("got image")
		#image.save()
		payload = {'data1': image1}
		return render(request, template, payload)
		t=loader.get_template(template)
		c = {'dataimg': 'image'}
		return HttpResponse(t.render(c,request))
	else:
		print("None")'''

def displayFrame(request):
	template_name = 'scoutbot/showImage.html'
	context = {
		'commands': video.objects.all(),
		'latest': video.objects.all()[video.objects.count()-1]
	}
	return render(request, template_name, context)
